﻿

using System.Collections;
using System.Text;
namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //var sw = System.Diagnostics.Stopwatch.StartNew();
            //List<long> times = new List<long>();
            //int j = 0;
            //while (true)
            //{
            //    StringBuilder sb = new StringBuilder();
            //    long t1 = sw.ElapsedMilliseconds;
            //    for (int i = 0; i < int.MaxValue / 50; i++)
            //    {
            //        sb.Append(i);
            //        sb.Append("Hello");
            //    }
            //    long t2 = sw.ElapsedMilliseconds;
            //    Console.WriteLine(t2-t1); 
            //    j++;
            //    sw.Restart();
            //}



            DateTime startTime, endTime;
            int count = int.Parse(args == null || args.Length == 0 ? "10000000" : args[0]);
            Console.WriteLine(count);
            startTime = DateTime.Now;

            //Span<StringBuilder> list = new Span<StringBuilder>();
            LinkedList<StringBuilder> list = new LinkedList<StringBuilder>();

            for (int i = 0; i < count; i++)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append($"hellow world.{i}");
                //list.Fill(sb);
                list.AddLast(sb);
            }
            //foreach (StringBuilder sb in list)
            //{
            //    sb.ToString();
            //}
            endTime = DateTime.Now;
            Console.WriteLine((endTime - startTime).TotalMilliseconds);



            return;
        }
    }
}
